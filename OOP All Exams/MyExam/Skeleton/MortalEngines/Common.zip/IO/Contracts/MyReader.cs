﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MortalEngines.IO.Contracts
{
    public class MyReader
    {
        public string Read()
        {
            return Console.ReadLine();
        }
    }
}
