﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CosmosX.Entities.Modules.Absorbing
{
    public class CooldownSystem : BaseAbsorbingModule
    {
        public CooldownSystem(int id, int heatAbsorbing) 
            : base(id, heatAbsorbing)
        {
        }
    }
}
