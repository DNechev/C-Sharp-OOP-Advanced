﻿namespace CosmosX.Entities.CommonContracts
{
    public interface IIdentifiable
    {
        int Id { get; }
    }
}