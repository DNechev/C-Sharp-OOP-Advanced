﻿using System;
using System.Collections.Generic;
using System.Text;

public class Ruby : Gem
{
    public Ruby(GemClarity clarity) 
        : base(clarity, 7, 2, 5)
    {
    }
}